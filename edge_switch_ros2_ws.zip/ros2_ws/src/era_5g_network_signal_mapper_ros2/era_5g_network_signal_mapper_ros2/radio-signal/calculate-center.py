import matplotlib.pyplot as plt
import numpy as np

# Define the points
# = (5.892994155733665, 1.1204277220064542)#(0.5528371865710586, 1.2203975456412288)
#B = (4.993175026459608, 2.047461504963372) #(5.050146392135469, 2.3906599194856195)#
#C = (3.0341397091310314, 2.753499491744592)#(3.108946050732007, 2.826342851258809)
A = (0.5528371865710586, 1.2203975456412288)
B = (5.050146392135469, 2.3906599194856195)
C = (3.108946050732007, 2.826342851258809)


# Calculate the midpoints of AB and BC
mid_AB = ((A[0] + B[0]) / 2, (A[1] + B[1]) / 2)
mid_BC = ((B[0] + C[0]) / 2, (B[1] + C[1]) / 2)

# Calculate the slopes of AB and BC
slope_AB = (B[1] - A[1]) / (B[0] - A[0])
slope_BC = (C[1] - B[1]) / (C[0] - B[0])

# Calculate the perpendicular slopes
perp_slope_AB = -1 / slope_AB
perp_slope_BC = -1 / slope_BC

# Define the functions of the perpendicular bisectors
def perp_bisector(m, midpoint):
    # y = mx + c
    c = midpoint[1] - m * midpoint[0]
    return m, c

m_AB, c_AB = perp_bisector(perp_slope_AB, mid_AB)
m_BC, c_BC = perp_bisector(perp_slope_BC, mid_BC)

# Find the intersection of the two perpendicular bisectors
# m1*x + c1 = m2*x + c2
# x = (c2 - c1) / (m1 - m2)
x_center = (c_BC - c_AB) / (m_AB - m_BC)
y_center = m_AB * x_center + c_AB
center = (x_center, y_center)

# Calculate the radius of the circle
radius = np.sqrt((A[0] - center[0])**2 + (A[1] - center[1])**2)

# Plotting
fig, ax = plt.subplots()
circle = plt.Circle(center, radius, color='b', fill=False)
ax.add_artist(circle)

# Plot the points
ax.plot(*A, 'ro')
ax.plot(*B, 'ro')
ax.plot(*C, 'ro')
ax.plot(*center, 'go')  # center of the circle

# Plot the segments
ax.plot([A[0], B[0]], [A[1], B[1]], 'k-')
ax.plot([B[0], C[0]], [B[1], C[1]], 'k-')

# Plot the perpendicular bisectors
x_vals = np.linspace(-5, 5, 400)
y_vals_AB = m_AB * x_vals + c_AB
y_vals_BC = m_BC * x_vals + c_BC
ax.plot(x_vals, y_vals_AB, 'r--')
ax.plot(x_vals, y_vals_BC, 'r--')

ax.set_aspect('equal', 'box')
plt.xlim(-5, 5)
plt.ylim(-5, 5)
plt.xlabel('X')
plt.ylabel('Y')
plt.title('Circle through three points')
plt.grid(True)
plt.show()

print(f"Center of the circle: {center}")
print(f"Radius of the circle: {radius}")
