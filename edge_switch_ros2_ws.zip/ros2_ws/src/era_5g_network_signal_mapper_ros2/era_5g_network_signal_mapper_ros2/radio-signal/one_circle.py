#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
import numpy as np
from sensor_msgs.msg import PointCloud2, PointField
from std_msgs.msg import Header
import struct
class CirclePublisher(Node):
    def __init__(self):
        super().__init__('circle_publisher')
        self.declare_parameter('radius', 3.0)
        self.declare_parameter('num_points', 100)
        self.declare_parameter('center_x', 3.0)
        self.declare_parameter('center_y', 0.0)
        self.declare_parameter('center_z', 0.0)
        self.publisher_ = self.create_publisher(PointCloud2, '/radio_antenna_signal', 10)
        # Remove timer and call publish_circle directly
        self.publish_circle()
    def publish_circle(self):
        radius = self.get_parameter('radius').get_parameter_value().double_value
        num_points = self.get_parameter('num_points').get_parameter_value().integer_value
        center_x = self.get_parameter('center_x').get_parameter_value().double_value
        center_y = self.get_parameter('center_y').get_parameter_value().double_value
        center_z = self.get_parameter('center_z').get_parameter_value().double_value
        theta = np.linspace(0, 2 * np.pi, num_points)
        x = radius * np.cos(theta) + center_x
        y = radius * np.sin(theta) + center_y
        z = np.full(num_points, center_z)
        points = np.vstack((x, y, z)).transpose()
        header = Header()
        header.stamp = self.get_clock().now().to_msg()
        header.frame_id = 'map'
        fields = [
            PointField(name='x', offset=0, datatype=PointField.FLOAT32, count=1),
            PointField(name='y', offset=4, datatype=PointField.FLOAT32, count=1),
            PointField(name='z', offset=8, datatype=PointField.FLOAT32, count=1),
            PointField(name='rgb', offset=12, datatype=PointField.UINT32, count=1),
        ]
        pointcloud_data = []
        for p in points:
            x, y, z = p
            r, g, b = 255, 255, 0  # RGB values for yellow color
            a = 0  # Alpha value
            rgb = struct.unpack('I', struct.pack('BBBB', b, g, r, a))[0]
            pointcloud_data.append([x, y, z, rgb])
        pointcloud_data = np.array(pointcloud_data, dtype=np.float32)
        pointcloud_msg = PointCloud2()
        pointcloud_msg.header = header
        pointcloud_msg.height = 1
        pointcloud_msg.width = num_points
        pointcloud_msg.fields = fields
        pointcloud_msg.is_bigendian = False
        pointcloud_msg.point_step = 16
        pointcloud_msg.row_step = pointcloud_msg.point_step * pointcloud_msg.width
        pointcloud_msg.is_dense = True
        pointcloud_msg.data = pointcloud_data.tobytes()
        self.publisher_.publish(pointcloud_msg)
        self.get_logger().info('Publishing circle pointcloud with radius: %.2f, %d points, center: (%.2f, %.2f, %.2f)' % (radius, num_points, center_x, center_y, center_z))
def main(args=None):
    rclpy.init(args=args)
    node = CirclePublisher()
    rclpy.spin_once(node)  # Spin once to process the publish call
    node.destroy_node()
    rclpy.shutdown()
if __name__ == '__main__':
    main()