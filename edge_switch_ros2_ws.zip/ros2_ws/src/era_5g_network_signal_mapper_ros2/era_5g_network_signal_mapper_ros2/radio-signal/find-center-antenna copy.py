import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from geometry_msgs.msg import PoseWithCovarianceStamped
class ColorChangeRecorder(Node):
    def __init__(self):
        super().__init__('color_change_recorder')
        self.color_subscriber = self.create_subscription(String, '/pcl_colour', self.color_callback, 10)
        self.position_subscriber = self.create_subscription(PoseWithCovarianceStamped, '/amcl_pose', self.position_callback, 10)
        self.coordinates = []
        self.previous_color = None
        self.color_change_count = 0
    def color_callback(self, msg):
        current_color = msg.data
        if self.previous_color is not None:
            if self.previous_color == 'YELLOW' and current_color == 'GREEN':
                self.color_change_count += 1
                self.coordinates.append((msg.pose.pose.position.x, msg.pose.pose.position.y))
                if self.color_change_count >= 3:
                    self.get_logger().info('Detected three color changes. Stopping the robot.')
                    self.stop_robot()
        self.previous_color = current_color
    def position_callback(self, msg):
        if self.color_change_count < 3 and self.previous_color is not None:
            if (self.previous_color == 'YELLOW' or self.previous_color == 'GREEN'):
                self.coordinates.append((msg.pose.pose.position.x, msg.pose.pose.position.y))
                self.get_logger().info(f'Added coordinate: ({msg.pose.pose.position.x}, {msg.pose.pose.position.y})')
    def stop_robot(self):
        # Perform actions to stop the robot
        self.get_logger().info('Array of coordinates where color changed:')
        for coord in self.coordinates:
            print(str(coord))
            #self.get_logger().info(coord)
def main(args=None):
    rclpy.init(args=args)
    node = ColorChangeRecorder()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
if __name__ == '__main__':
    main()