import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from geometry_msgs.msg import PoseWithCovarianceStamped
class ColorChangeRecorder(Node):
    def __init__(self):
        super().__init__('color_change_recorder')
        self.color_subscriber = self.create_subscription(String, '/pcl_colour', self.color_callback, 10)
        self.position_subscriber = self.create_subscription(PoseWithCovarianceStamped, '/amcl_pose', self.position_callback, 10)
        self.coordinates = []
        self.previous_color = None
        self.current_color = None
    def color_callback(self, msg):
        self.previous_color = self.current_color
        self.current_color = msg.data
        if self.previous_color is not None and self.previous_color != self.current_color:
            if (self.previous_color == 'YELLOW' and self.current_color == 'GREEN') or \
               (self.previous_color == 'GREEN' and self.current_color == 'YELLOW'):
                self.add_coordinate()
    def position_callback(self, msg):
        self.robot_position = msg.pose.pose.position
    def add_coordinate(self):
        x = self.robot_position.x
        y = self.robot_position.y
        self.coordinates.append((x, y))
        self.get_logger().info(f'Added coordinate: ({x}, {y})')
        if len(self.coordinates) == 3:
            self.get_logger().info('Detected three color change coordinates. Stopping the robot.')
            for coordinate in self.coordinates:
                self.get_logger().info(f'Coordinate: {coordinate}')
            # Implement code to stop the robot here
def main(args=None):
    rclpy.init(args=args)
    node = ColorChangeRecorder()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
if __name__ == '__main__':
    main()
