import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseWithCovarianceStamped
from std_msgs.msg import String

class ColorChangeListener(Node):

    def __init__(self):
        super().__init__('color_change_listener')
        
        # Subscribe to the amcl_pose topic
        self.pose_subscriber = self.create_subscription(
            PoseWithCovarianceStamped,
            'amcl_pose',
            self.pose_callback,
            10
        )
        
        # Subscribe to the pcl_colour topic
        self.color_subscriber = self.create_subscription(
            String,
            'pcl_colour',
            self.color_callback,
            10
        )
        
        # Variables to store the current pose and color
        self.current_pose = None
        self.previous_color = None
        self.coordinates_list = []

    def pose_callback(self, msg):
        self.current_pose = msg.pose.pose

    def color_callback(self, msg):
        current_color = msg.data

        # Check for color change between green and yellow
        if self.previous_color is not None:
            if (self.previous_color == 'RED' and current_color == 'YELLOW') or (self.previous_color == 'YELLOW' and current_color == 'RED'):
                if self.current_pose is not None:
                    coordinates = (self.current_pose.position.x, self.current_pose.position.y, self.current_pose.position.z)
                    self.coordinates_list.append(coordinates)
                    self.get_logger().info(f'Color changed from {self.previous_color} to {current_color}. Coordinates: {coordinates}')

        # Update the previous color
        self.previous_color = current_color

    def print_last_three_coordinates(self):
        # Print the last three sets of coordinates
        if len(self.coordinates_list) >= 3:
            self.get_logger().info('Last three sets of coordinates:')
            for coords in self.coordinates_list[-3:]:
                self.get_logger().info(f'Coordinates: x={coords[0]}, y={coords[1]}, z={coords[2]}')
        else:
            self.get_logger().info('Not enough data to display three sets of coordinates.')

def main(args=None):
    rclpy.init(args=args)
    node = ColorChangeListener()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.print_last_three_coordinates()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
