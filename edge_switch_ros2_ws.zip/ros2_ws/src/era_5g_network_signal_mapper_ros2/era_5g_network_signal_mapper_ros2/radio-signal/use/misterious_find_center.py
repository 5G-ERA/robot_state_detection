import rclpy
from rclpy.node import Node
from sensor_msgs.msg import PointCloud2
from geometry_msgs.msg import PoseWithCovarianceStamped
import numpy as np
import struct
class CircleCenterEstimator(Node):
    def __init__(self):
        super().__init__('circle_center_estimator')
        self.pointcloud_sub = self.create_subscription(
            PointCloud2,
            '/radio_antenna_signal',
            self.pointcloud_callback,
            10)
        self.pose_sub = self.create_subscription(
            PoseWithCovarianceStamped,
            '/amcl_pose',
            self.pose_callback,
            10)
        self.edge_points = []
        self.robot_pose = None
    def pointcloud_callback(self, msg):
        # Unpack point cloud data
        for i in range(0, len(msg.data), msg.point_step):
            x, y, z, rgb = struct.unpack_from('ffffI', msg.data, offset=i)
            color = self.rgb_to_color(rgb)
            if self.is_edge_point(color):
                self.edge_points.append((x, y))
                self.get_logger().info(f'Appended edge point: ({x}, {y})')
        if self.robot_pose is not None:
            self.estimate_circle_center()
    def pose_callback(self, msg):
        self.robot_pose = msg.pose.pose
    def estimate_circle_center(self):
        if len(self.edge_points) < 3:
            self.get_logger().info('Not enough edge points to estimate the circle center')
            return
        # Use numpy to find the center of the circle using a simple algorithm
        points_array = np.array(self.edge_points)
        A = np.c_[points_array[:, 0], points_array[:, 1], np.ones(points_array.shape[0])]
        b = np.sum(points_array**2, axis=1)
        c = np.linalg.lstsq(A, b, rcond=None)[0]
        xc = 0.5 * c[0]
        yc = 0.5 * c[1]
        radius = np.sqrt(c[2] + xc**2 + yc**2)
        self.get_logger().info(f'Estimated center: ({xc}, {yc}), Radius: {radius}')
    def is_edge_point(self, color):
        # Check if the point represents an edge between colors
        return color in ['green_to_yellow', 'yellow_to_red', 'red_to_yellow', 'yellow_to_green']
    def rgb_to_color(self, rgb):
        # Convert RGB value to color
        r = (rgb >> 16) & 0xff
        g = (rgb >> 8) & 0xff
        b = rgb & 0xff
        if r == 0 and g == 255 and b == 0:
            return 'green_to_yellow'
        elif r == 255 and g == 255 and b == 0:
            return 'yellow_to_red'
        elif r == 255 and g == 0 and b == 0:
            return 'red_to_yellow'
        elif r == 255 and g == 255 and b == 0:
            return 'yellow_to_green'
        else:
            return 'unknown'
def main(args=None):
    rclpy.init(args=args)
    node = CircleCenterEstimator()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
if __name__ == '__main__':
    main()