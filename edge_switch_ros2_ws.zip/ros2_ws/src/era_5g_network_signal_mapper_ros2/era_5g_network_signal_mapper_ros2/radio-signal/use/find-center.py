import rclpy
from rclpy.node import Node
from sensor_msgs.msg import PointCloud2
from geometry_msgs.msg import PoseWithCovarianceStamped
import numpy as np
import struct
class CircleCenterEstimator(Node):
    def __init__(self):
        super().__init__('circle_center_estimator')
        self.pointcloud_sub = self.create_subscription(
            PointCloud2,
            '/radio_antenna_signal',
            self.pointcloud_callback,
            10)
        self.pose_sub = self.create_subscription(
            PoseWithCovarianceStamped,
            '/amcl_pose',
            self.pose_callback,
            10)
        self.green_points = []
        self.yellow_points = []
        self.red_points = []
        self.robot_pose = None
    def pointcloud_callback(self, msg):
        # Unpack point cloud data
        for i in range(0, len(msg.data), msg.point_step):
            x, y, z, rgb = struct.unpack_from('ffffI', msg.data, offset=i)
            color = self.rgb_to_color(rgb)
            if color == 'green':
                self.green_points.append((x, y))
            elif color == 'yellow':
                self.yellow_points.append((x, y))
            elif color == 'red':
                self.red_points.append((x, y))
        if self.robot_pose is not None:
            self.estimate_circle_center()
    def pose_callback(self, msg):
        self.robot_pose = msg.pose.pose
    def estimate_circle_center(self):
        if len(self.green_points) < 3 or len(self.yellow_points) < 3 or len(self.red_points) < 3:
            self.get_logger().info('Not enough points of each color to estimate the circle center')
            return
        # Estimate center for each color separately
        green_center = self.estimate_center(self.green_points)
        yellow_center = self.estimate_center(self.yellow_points)
        red_center = self.estimate_center(self.red_points)
        self.get_logger().info(f'Estimated center for green points: {green_center}')
        self.get_logger().info(f'Estimated center for yellow points: {yellow_center}')
        self.get_logger().info(f'Estimated center for red points: {red_center}')
    def estimate_center(self, points):
        # Use numpy to find the center of the circle using a simple algorithm
        points_array = np.array(points)
        A = np.c_[points_array[:, 0], points_array[:, 1], np.ones(points_array.shape[0])]
        b = np.sum(points_array**2, axis=1)
        c = np.linalg.lstsq(A, b, rcond=None)[0]
        xc = 0.5 * c[0]
        yc = 0.5 * c[1]
        radius = np.sqrt(c[2] + xc**2 + yc**2)
        return (xc, yc, radius)
    def rgb_to_color(self, rgb):
        # Convert RGB value to color
        r = (rgb >> 16) & 0xff
        g = (rgb >> 8) & 0xff
        b = rgb & 0xff
        if r == 0 and g == 255 and b == 0:
            return 'green'
        elif r == 255 and g == 255 and b == 0:
            return 'yellow'
        elif r == 255 and g == 0 and b == 0:
            return 'red'
        else:
            return 'unknown'
def main(args=None):
    rclpy.init(args=args)
    node = CircleCenterEstimator()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
if __name__ == '__main__':
    main()