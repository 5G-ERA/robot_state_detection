#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import PointCloud2
import sensor_msgs_py.point_cloud2 as pc2
import numpy as np
class CircleCenterFinder(Node):
    def __init__(self):
        super().__init__('circle_center_finder')
        self.subscription = self.create_subscription(
            PointCloud2,
            '/radio_antenna_signal',
            self.pointcloud_callback,
            10)
        self.green_points = []
    def pointcloud_callback(self, msg):
        # Extract points from PointCloud2 message
        points = list(pc2.read_points(msg, field_names=("x", "y", "z", "rgb"), skip_nans=True))
        # Filter green points
        self.green_points = [p for p in points if self.is_green(p[3])]
        if len(self.green_points) >= 3:
            center = self.calculate_circle_center(self.green_points)
            if center:
                self.get_logger().info(f'Calculated circle center: {center}')
            else:
                self.get_logger().warn('Failed to calculate circle center.')
    def is_green(self, rgb_value):
        # Unpack the RGB value
        b = int(rgb_value) & 0xFF
        g = (int(rgb_value) >> 8) & 0xFF
        r = (int(rgb_value) >> 16) & 0xFF
        # Yellow color in RGB (255, 255, 0)
        return r == 255 and g == 255 and b == 0
    def calculate_circle_center(self, points):
        # Convert to numpy array for easier manipulation
        points = np.array([[p[0], p[1]] for p in points])
        # Use least squares method to fit a circle to the points
        A = np.c_[points[:, 0], points[:, 1], np.ones(points.shape[0])]
        b = np.sum(points**2, axis=1)
        coeff, _, _, _ = np.linalg.lstsq(A, b, rcond=None)
        # Circle center coordinates
        x_center = coeff[0] / 2
        y_center = coeff[1] / 2
        return (x_center, y_center)
def main(args=None):
    rclpy.init(args=args)
    node = CircleCenterFinder()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
if __name__ == '__main__':
    main()