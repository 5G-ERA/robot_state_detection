#!/usr/bin/env python3

import rclpy
import numpy as np
import std_msgs.msg as std_msgs
import struct
import sensor_msgs_py.point_cloud2 as pcl2
import math
import era_5g_network_signal_mapper_ros2.declare_param as paramm
from sensor_msgs.msg import PointCloud2, PointField
from geometry_msgs.msg import TransformStamped
from rclpy.node import Node
from tf2_ros import TransformBroadcaster
from tf2_ros import TransformException
from geometry_msgs.msg import PoseWithCovarianceStamped
from rclpy.qos import QoSDurabilityPolicy, QoSHistoryPolicy, QoSReliabilityPolicy
from rclpy.qos import QoSProfile



radius = 0.0 # initial circle radius
duration = 0.05 # 7 sec
#duration = 0.12 #
steps = 5 # Number of 'moves' or points on the circle
#steps = 5 ; duration = 0.12 = 31 circles
#steps = 5 ; duration = 0.05  = 20 circles

mid_x = -3.0 # x coordinate of antena
mid_y = 0.0 # y coordinate of antena

def GetXnY(angl):
    x = radius * math.sin(math.pi * 2 * angl / 360)
    y = radius * math.cos(math.pi * 2 * angl / 360)
    return (x, y)

class FramePublisher(Node):

    def __init__(self):
        super().__init__('robot_tf2_frame_publisher')

        # Retreive parameters from param / launch or params.yaml file / ENV or set default values automaticaly
        self.get_logger().info('Retriving params signal_mapper', once=True)
        #self.robot_base_frame = paramm.param_set_string(self,'my_base_link', 'base_footprint')
        self.map_frame = paramm.param_set_string(self,'my_map_frame', 'map')
        self.semantic_map_frame = paramm.param_set_string(self,'my_semantic_map_frame', 'semantic_map')
        
        # Boundingbox of the pcl2 publish around the robot
        global height, lenght, lamba, x_my, y_my, angle
        angle = 0.0

        height = 0.3
        lenght = 0.3
        lamba = 0.05

        # Creating publisher for which will publish cloud formed from pointclouds at current position of robot
        self.current_pcl_pub = self.create_publisher(PointCloud2, '/current_semantic_pcl', 10)

        amcl_pose_qos = QoSProfile(
            durability=QoSDurabilityPolicy.TRANSIENT_LOCAL,
            reliability=QoSReliabilityPolicy.RELIABLE,
            history=QoSHistoryPolicy.KEEP_LAST,
            depth=1)

        
        self.model_pose_sub = self.create_subscription(PoseWithCovarianceStamped,
                                                '/amcl_pose',
                                                self._amclPoseCallback,
                                                amcl_pose_qos)
        # Initialize the transform broadcaster
        self.tf_broadcaster = TransformBroadcaster(self)
        self.timer = self.create_timer(duration, self.on_timer3)
        self.timer = self.create_timer(duration, self.on_timer)

    def on_timer(self):
            try:

                self.model_pose_sub
                #print("here!!her")
                global d                
                self.send_transformation_of_frames()
                self.create_simple_pointcloud()

            except TransformException as ex:
                    self.get_logger().info(str(ex))

         
    def on_timer3(self):
        global angle, steps, radius, duration
        x, y = GetXnY(angle)
        global x_my, y_my

        if angle > 360:
            print(angle)
            angle = 0
            radius = radius + 0.5
            steps = steps + 5

        # change colour
        global r, g, b
        if radius == 0:#"GREEN":
            self.get_logger().info("CHANGE TO GREEN",once = True)
            r = 255
            g = 255
            b = 0
        elif radius == 3:#"YELLOW":
            self.get_logger().info("CHANGE TO YELLOW",once = True)
            r = 124
            g = 252
            b = 0            
        elif radius == 4.5:#"ORANGE":
            self.get_logger().info("CHANGE TO ORANGE",once = True)
            r = 127
            g = 191
            b = 0
        elif radius == 6:#"RED":
            self.get_logger().info("CHANGE TO RED",once = True)
            r = 127
            g = 0
            b = 0
        elif radius == 10:#"BLUE":
            self.get_logger().info("CHANGE TO BLUE",once = True)
            r = 0
            g = 0
            b = 255

        x_my = mid_x + x
        y_my = mid_y + y        
        angle = angle + (360/steps)
    #finish
        

    def _amclPoseCallback(self, msg):
        global d
        d = msg
        self.initial_pose_received = True
        return
    
    def send_transformation_of_frames(self):
            
            t = TransformStamped()
            global x_my, y_my

            # Read message content and assign it to
            # corresponding tf variables
            t.header.stamp = self.get_clock().now().to_msg()
            t.header.frame_id = self.map_frame
            t.child_frame_id = self.semantic_map_frame
            # Robot only exists in 2D, thus we get x and y translation
            # coordinates from the message and set the z coordinate to 0
            t.transform.translation.x =  x_my #trans.transform.translation.x
            t.transform.translation.y = y_my #trans.transform.translation.y
            t.transform.translation.z = 0.0 #trans.transform.translation.z

            # For the same reason, robot can only rotate around one axis
            # and this why we set rotation in x and y to 0 and obtain
            # rotation in z axis from the message
            t.transform.rotation.x = 0.0 #trans.transform.rotation.x
            t.transform.rotation.y = 0.0 #trans.transform.rotation.y
            t.transform.rotation.z = 0.0 #trans.transform.rotation.z
            t.transform.rotation.w = 1.0

            # Send the transformation
            self.tf_broadcaster.sendTransform(t)

    def create_simple_pointcloud(self):

        global r, g, b
        rgb = struct.unpack('I', struct.pack('BBBB', b, g, r, 0))[0]
        #print(rgb)

        cloud_points = []

        # Creating point clouds of the current position of the robot 
        for x in np.arange(0,height,lamba):
            for y in np.arange(-lenght,lenght,lamba):
                cloud_points.append([x, y, 0.0, rgb])
                cloud_points.append([-x, y, 0.0, rgb])


        # ROS DATATYPE 
        ros_dtype = PointField.FLOAT32

        # The PointCloud2 message also has a header which specifies which 
        # coordinate frame it is represented in.
        header = std_msgs.Header()
        
        # The fields specify what the bytes represents. The first 4 bytes 
        # represents the x-coordinate, the next 4 the y-coordinate, etc.
        
        fields = [
            PointField(name='x', offset=0, datatype=ros_dtype, count=1),
            PointField(name='y', offset=4, datatype=ros_dtype, count=1),
            PointField(name='z', offset=8, datatype=ros_dtype, count=1),
            # The 4th set of bytes represent colour of pointcloud
            PointField(name='rgb', offset=12, datatype=PointField.FLOAT32, count=1)
        ]
        # creating a cloud and store in pcl_msg
        pcl_msg = pcl2.create_cloud(header, fields, cloud_points)
        pcl_msg.header.stamp = self.get_clock().now().to_msg()
        pcl_msg.header.frame_id = self.semantic_map_frame

        # Publishing cloud created at the current possition of the robot
        self.current_pcl_pub.publish(pcl_msg)

def main():
    rclpy.init()
    node = FramePublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()
