# era_5g_network_application_template

Run `pip3 install --extra-index-url https://rospypi.github.io/simple/ ros-stubs-all` to install ROS1 typing stubs (necessary for `mypy`).